import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'firebase/firebase_options.dart';
import 'admin_login_page.dart';
import 'admin_home_page.dart';  

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const CaneVisionAdminApp());
}

class CaneVisionAdminApp extends StatelessWidget {
  const CaneVisionAdminApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CaneVision Admin',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF11BD51),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        scrollbarTheme: ScrollbarThemeData(
          thumbColor: WidgetStateProperty.all(
              const Color(0xFF11BD51).withOpacity(0.4)),
        ),
      ),
      home: const AuthWrapper(),
    );
  }
}

/// Listens to Firebase auth state.
/// - Logged in + role == Admin → AdminHomePage
/// - Otherwise → AdminLoginPage
class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            backgroundColor: Color(0xFFE8F8EF),
            body: Center(
              child: CircularProgressIndicator(
                color: Color(0xFF11BD51),
                strokeWidth: 2.5,
              ),
            ),
          );
        }
        if (snapshot.hasData && snapshot.data != null) {
          return const AdminHomePage();
        }
        return const AdminLoginPage();
      },
    );
  }
}